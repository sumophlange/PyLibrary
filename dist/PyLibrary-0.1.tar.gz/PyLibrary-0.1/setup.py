from setuptools import setup

setup(name='PyLibrary',
      version='0.1',
      description='Margin calculator',
      url='http://github.com/sumophlange/PyLibrary',
      author='John Hopkins',
      author_email='john_hopkins86@hotmail.com',
      license='MIT',
      packages=['PyLibrary'],
      zip_safe=False)